import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

class LocationSearchResult {
  final String label;
  final LatLng point;
  const LocationSearchResult({required this.label, required this.point});
}

class LocationSearchService {
  LocationSearchService._();
  static final instance = LocationSearchService._();

  // 8.9: piccolo indice locale per le località usate più spesso nei test e
  // nelle Dolomiti venete. Serve a Pianifica anche senza rete: se la località
  // è nell'indice non viene fatta alcuna chiamata a Nominatim.
  static final Map<String, LocationSearchResult> _offlinePlaces = {
    'auronzo': const LocationSearchResult(
      label: 'Auronzo di Cadore (BL)',
      point: LatLng(46.5503, 12.4416),
    ),
    'auronzo di cadore': const LocationSearchResult(
      label: 'Auronzo di Cadore (BL)',
      point: LatLng(46.5503, 12.4416),
    ),
    'misurina': const LocationSearchResult(
      label: 'Misurina (BL)',
      point: LatLng(46.5828, 12.2547),
    ),
    'cortina': const LocationSearchResult(
      label: "Cortina d'Ampezzo (BL)",
      point: LatLng(46.5405, 12.1357),
    ),
    "cortina d'ampezzo": const LocationSearchResult(
      label: "Cortina d'Ampezzo (BL)",
      point: LatLng(46.5405, 12.1357),
    ),
    'belluno': const LocationSearchResult(
      label: 'Belluno (BL)',
      point: LatLng(46.1399, 12.2176),
    ),
    'alleghe': const LocationSearchResult(
      label: 'Alleghe (BL)',
      point: LatLng(46.4074, 12.0242),
    ),
    'selva di cadore': const LocationSearchResult(
      label: 'Selva di Cadore (BL)',
      point: LatLng(46.4506, 12.0564),
    ),
    'arabba': const LocationSearchResult(
      label: 'Arabba (BL)',
      point: LatLng(46.4971, 11.8752),
    ),
    'san vito di cadore': const LocationSearchResult(
      label: 'San Vito di Cadore (BL)',
      point: LatLng(46.4618, 12.2067),
    ),
    'borca di cadore': const LocationSearchResult(
      label: 'Borca di Cadore (BL)',
      point: LatLng(46.4360, 12.2221),
    ),
    'pieve di cadore': const LocationSearchResult(
      label: 'Pieve di Cadore (BL)',
      point: LatLng(46.4271, 12.3747),
    ),
    'poz zale di cadore': const LocationSearchResult(
      label: 'Pozzale di Cadore (BL)',
      point: LatLng(46.4148, 12.3754),
    ),
    'pozzale di cadore': const LocationSearchResult(
      label: 'Pozzale di Cadore (BL)',
      point: LatLng(46.4148, 12.3754),
    ),
    'sappada': const LocationSearchResult(
      label: 'Sappada (UD)',
      point: LatLng(46.5684, 12.6841),
    ),
    'longarone': const LocationSearchResult(
      label: 'Longarone (BL)',
      point: LatLng(46.2673, 12.3015),
    ),
    'feltre': const LocationSearchResult(
      label: 'Feltre (BL)',
      point: LatLng(46.0189, 11.9068),
    ),
    'agordo': const LocationSearchResult(
      label: 'Agordo (BL)',
      point: LatLng(46.2827, 12.0340),
    ),
    'falcade': const LocationSearchResult(
      label: 'Falcade (BL)',
      point: LatLng(46.3563, 11.8736),
    ),
    'venezia': const LocationSearchResult(
      label: 'Venezia (VE)',
      point: LatLng(45.4408, 12.3155),
    ),
    'mestre': const LocationSearchResult(
      label: 'Mestre (VE)',
      point: LatLng(45.4935, 12.2416),
    ),
    'mira': const LocationSearchResult(
      label: 'Mira (VE)',
      point: LatLng(45.4342, 12.1331),
    ),
    'treviso': const LocationSearchResult(
      label: 'Treviso (TV)',
      point: LatLng(45.6669, 12.2430),
    ),
    'vicenza': const LocationSearchResult(
      label: 'Vicenza (VI)',
      point: LatLng(45.5455, 11.5354),
    ),
    'verona': const LocationSearchResult(
      label: 'Verona (VR)',
      point: LatLng(45.4384, 10.9916),
    ),
    'padova': const LocationSearchResult(
      label: 'Padova (PD)',
      point: LatLng(45.4064, 11.8768),
    ),
    'rovigo': const LocationSearchResult(
      label: 'Rovigo (RO)',
      point: LatLng(45.0703, 11.7901),
    ),
  };

  String _normalize(String value) => value
      .trim()
      .toLowerCase()
      .replaceAll('à', 'a')
      .replaceAll('è', 'e')
      .replaceAll('é', 'e')
      .replaceAll('ì', 'i')
      .replaceAll('ò', 'o')
      .replaceAll('ù', 'u')
      .replaceAll(RegExp(r'\\s+'), ' ');

  Future<LocationSearchResult?> search(String query) async {
    final q = query.trim();
    if (q.isEmpty) return null;

    final normalized = _normalize(q);
    final local = _offlinePlaces[normalized];
    if (local != null) return local;

    // Se non è nel piccolo indice locale proviamo il servizio online, ma senza
    // lasciare l'utente bloccato 15 secondi. In assenza rete torniamo null.
    final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
      'q': q,
      'format': 'jsonv2',
      'limit': '1',
      'countrycodes': 'it',
    });

    try {
      final response = await http
          .get(
            uri,
            headers: const {
              'User-Agent': 'GoTr-AI/8.9 (planning search)',
              'Accept-Language': 'it',
            },
          )
          .timeout(const Duration(seconds: 5));

      if (response.statusCode != 200) return null;

      final decoded = jsonDecode(response.body);
      if (decoded is! List || decoded.isEmpty) return null;

      final first = Map<String, dynamic>.from(decoded.first as Map);
      final lat = double.tryParse(first['lat']?.toString() ?? '');
      final lon = double.tryParse(first['lon']?.toString() ?? '');
      if (lat == null || lon == null) return null;

      return LocationSearchResult(
        label: first['display_name']?.toString() ?? q,
        point: LatLng(lat, lon),
      );
    } catch (_) {
      return null;
    }
  }
}
